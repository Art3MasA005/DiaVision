# Handoff: Bye Bye Diabetes — 19-screen mobile app

## Overview

A diabetes risk-and-management app for Bangladesh (first market), designed mobile-first, bilingual Bangla/English with 15 languages scaffolded. A person answers eleven questions about themselves and gets back a **calibrated range** estimate of undetected high blood sugar, plus the two or three things they can actually change. Around that core sit day-to-day tracking (meals, glucose, activity, check-ins), an AI coach, insights with a clinician-shareable report, and the safety machinery that keeps a health app shippable.

The emotional brief: **calm, clinical, warm.** Not gamified, not cheerful, never scolding. A rising risk number must never be styled as an alarm.

## About the design files

The files in this bundle are **design references created in HTML** — a prototype showing intended look, copy, and behavior. They are **not production code to copy**. `ByeByeDiabetes App.dc.html` is a single-file HTML prototype that renders all 19 screens inside a phone frame with a screen index and a developer-handoff panel; it uses a bespoke inline-style runtime and will not drop into a real app.

Your job is to **recreate these designs in the target codebase's own environment**, using its established patterns, component library, and navigation. The original product spec (`ui_spec.md`, included) targets **Flutter**; if that is the codebase, build these as Flutter widgets against the frozen `feature_spec.json` contract. If no environment exists yet, pick the most appropriate framework for a two-platform mobile product and implement there.

## Fidelity

**High fidelity.** Final colors, type, spacing, radii, copy (EN + BN), interaction states, empty/error/offline states, and both light and dark themes are specified. Recreate the UI closely, substituting the codebase's existing primitives where they already match. Exact values are in `design-tokens.json` and repeated inline below.

Two things are deliberately unfinished:
- **Meal photography** is a placeholder block on the camera-review screen. Real food images needed.
- **Illustration for the waist-measurement guide** (spec §2 screen 07) is not drawn. The prototype covers it with a "Why do we ask?" text explainer instead; a wordless diagram is still required per spec.

## Hard product rules — read before designing anything

These come from App Store guideline 1.4.1, Play's health policy, and the product's safety rails (`ui_spec.md` §1). Breaking one gets the app rejected or hurts a user.

1. **Never a bare number.** Risk is always a range — `25–41%`, never `33%`.
2. **Never the word "diagnosis"** (nor diagnose, cure, treat, reverse, clinically proven, medically accurate).
3. **Never "scan your health"** — implying vitals from device sensors is an auto-reject. The camera screen scans *food*, and says so.
4. **Never red for a bad number.** Safety red `#9f1239` appears on safety cards and nowhere else.
5. **Never hide the disclaimer.** Persistent footer on every screen showing a risk figure. Not a dismissible modal.
6. **Never skip the doctor CTA** on a risk result.
7. **Never fixed-height text containers.** Bangla runs taller than Latin; German ~35% longer.
8. **Never `left`/`right`** — always `start`/`end`. Arabic and Urdu ship in Wave 3.
9. **Never text baked into an image.**
10. **Never below 16sp body text.** Older adults are a core demographic.
11. **Never let an under-18 through.** Enforced server-side too; the UI must not offer the path.

## Architecture of the prototype

One screen is visible at a time inside a 392×846 phone frame (`border-radius: 44px`, `overflow: hidden`), composed of:

- **Status bar** — 14px 26px 4px padding, 13px/700 time + signal/wifi/battery glyphs. Chrome only; don't build.
- **Offline banner** (conditional) — 9px 13px pill strip, `--color-neutral-200` on `--color-neutral-300` border, 12px text, wifi-off icon. Quiet and persistent, never blocking.
- **Scrolling content** — `flex: 1; overflow-y: auto; padding: 0 18px 128px`. The 128px bottom pad clears the floating nav.
- **Floating nav pill** — absolute, `bottom: 20px`, centered, 5 items (Home, Tracker, Scan, Activity, Coach). Hidden on splash, auth, disclaimer, and calculating.
- **Toast** — absolute, `bottom: 104px`, inset-inline 22px, `--pill` bg / `--pill-fg` text, radius 18px, auto-dismiss 2600ms.
- **Bottom sheets** — `sheetUp` animation, used for language picker and profile switcher.

Every screen enters with `riseIn` (opacity 0→1, translateY 10px→0, 280ms ease).

---

# Screens

19 screens, in flow order. The prototype's left index lists them in this order.

## 01 · Splash

**Purpose:** cover the ~1.2s while the on-device risk model and region pack load. Brand only.

**Layout:** full-bleed `position: absolute; inset: 0` over the whole phone screen including status bar. `--color-accent-800` (#643312) ground. Centered column, `padding: 0 34px`, `text-align: center`.

**Components:**
- Three soft decorative circles, `border-radius: 999px`: 250px `--color-accent-700` at inline-start −70px / top −40px, opacity .55, `blobDrift 9s`; 290px `--color-accent-900` at inline-end −90px / bottom 120px, opacity .45, `blobDrift 11s reverse`; 56px `--color-accent-2-500` at inline-end 44px / top 118px, opacity .5.
- Logo mark: 104px circle, `#fffdf9` fill, `--shadow-lg`, containing the 50px Lucide activity glyph in `--color-accent-700`. `markIn` 700ms.
- Wordmark: heading 38px/1.06, `#fffdf9`, margin-top 24px, `riseIn` 120ms delay.
- Tagline: 15px/1.55, `--color-accent-200`, max-width 270px, `riseIn` 220ms delay.
- Loader: 132×5px track `--color-accent-700` radius 999px, 32%-wide `--color-accent-2-300` bar, `loadSlide 1.4s infinite`.
- Bottom block, absolute inset-inline 34px / bottom 34px: full-width `#fffdf9` pill button (padding 16px, heading 16px, `--color-accent-800` text, hover `--color-accent-100`) + 11.5px `--color-accent-300` footnote.

**Copy (EN / BN):**
- Wordmark: "Bye Bye Diabetes" / "বাই বাই ডায়াবেটিস"
- Tagline: "Know your risk. Change what you can." / "ঝুঁকি জানুন। যা বদলানো যায়, বদলান।"
- CTA: "Get started" / "শুরু করুন"
- Footnote: "Works offline · your data stays on this phone until you say otherwise"

**Rules:** no health claim, no number, no risk figure here — consent does not exist yet. Time out to auth after 3s rather than hanging. Cold start must not depend on the network.

**API:** `GET /regions/:code/pack`, `GET /session`.

## 02 · Log in / Sign up

**Purpose:** account creation and return. Phone-first — most users in this market have a number before an email.

**Layout:** standard scrolling content, `padding-top: 14px`.

**Components:**
- Brand row: 46px circle `--color-accent-100` / 1px `--color-accent-300` border, 23px activity icon `--color-accent-700`; beside it heading 19px/1.2 name + 12px/600 `--color-neutral-600` kicker.
- Segmented switcher: `--color-neutral-200` track, radius 999px, 4px padding, two flex-1 buttons radius 999px padding 11px 8px, 14px/700. Selected: `--card` bg, `--color-text`, `--shadow-sm`. Unselected: transparent, `--color-neutral-600`.
- Head: heading 26px/1.2, margin-top 20px. Sub: 14px/1.55 `--color-neutral-700`.
- Field cards (gap 10px): `--card` bg, 1.5px `--color-neutral-300` border, radius 22px, padding 13px 16px, `cursor: text`, hover border `--color-accent-300`. Inside: 11px uppercase .1em `--color-neutral-600` weight-700 label, then a row with a 17px Lucide icon in `--color-accent-700` + a borderless transparent input at 15.5px/600.
  - Login fields: phone (tel, phone icon), password (password, lock icon).
  - Signup fields: name (text, user icon), phone (tel), password (password).
- Login only: right-aligned ghost "Forgot password?" 13px/700 `--color-accent-700`.
- Signup only: Terms checkbox row — 24px square, radius 8px, 2px border; unchecked `--color-neutral-400` border on transparent, checked `--color-accent` fill + border with a 13px `--on-accent` check. Label 12.5px/1.5 `--color-neutral-700`.
- Submit: full-width pill, padding 16px, heading 16px. Enabled `--color-accent` / `--on-accent`; on signup with Terms unticked it is `--color-neutral-300` / `--color-neutral-600` and taps produce the "accept the Terms" toast rather than advancing.
- Divider: two 1px `--color-neutral-300` rules either side of an 11.5px uppercase .08em `--color-neutral-600` "or".
- Two outline pill buttons (gap 9px): 1.5px `--color-neutral-300`, `--card`, padding 13px 18px, 14.5px/700, 19px leading icon; hover border `--color-accent-300` + bg `--color-accent-100`. "Send me a one-time code" (message icon, `--color-accent-700`), "Continue with Google" (globe icon, `--color-accent-2-700`).
- Footnote card: `--color-neutral-200`, radius 18px, padding 13px 15px, 12px/1.55.

**Copy:** Login "Welcome back" / "Your logs and your risk history are where you left them." · Signup "Create your account" / "Eleven questions, about two minutes, and no blood test needed to start." · Terms "I agree to the Terms and the Privacy Policy. The medical disclaimer comes next and is separate." · Footnote "Phone sign-in is the default here — most people have a number before they have an email address. Nothing medical is asked on this screen." (Bangla equivalents in the prototype's `CONTENT.bn`.)

**Behavior:** login → Home; signup → Disclaimer. **Terms consent and medical disclaimer are two separate records** and must not be bundled. No health question on this screen. OTP is the primary path; password is the fallback.

**API:** `POST /auth/otp`, `POST /auth/verify`, `POST /accounts`, `POST /auth/session`. **Data:** Account, Session, Consent.

## 03 · Disclaimer — BLOCKING

**Purpose:** hard gate before any health question.

**Layout:** `padding-top: 22px`, scrolling content.

**Components:** 52px shield-check circle (`--color-accent-100` / `--color-accent-300` border / `--color-accent-700` icon) → heading 27px/1.2 → the disclaimer card (`--card`, 1px `--color-neutral-300`, radius 26px, padding 18px 17px, `--shadow-sm`, **15px/1.7 body — this is the one block that must not be shrunk**) → the tick row (26px square, radius 9px, 2px border; same checked treatment as signup; 14px/1.5 weight-600 label; whole row is a `role="checkbox"` button with 1.5px border radius 22px padding 15px 16px) → submit pill (inert grey until ticked) → 11.5px centered footnote.

**Verbatim string — never paraphrase, per spec §7:**

> Bye Bye Diabetes gives lifestyle and risk information. It is **not a medical device** and does **not diagnose or treat** any condition. Its estimates can be wrong. Always talk to a registered doctor before changing your diet, exercise, or any medication. If you take insulin or diabetes medication, do not change your dose based on this app.

The Bangla translation must be reviewed by a **native-speaking clinician** — not machine translation. Same for every safety string in the app.

**Rules:** no scroll-past, no pre-ticked box, no dismiss. Backend refuses signup without a recorded consent row (version + timestamp). No health question may render before this is accepted. Nav pill hidden.

**API:** `POST /consents`, `GET /consents/current`.

## 04 · Onboarding wizard (the eleven questions)

**Purpose:** collect the eleven fields the risk model needs. Six steps; the prototype shows step 2 (body measurements) as the representative screen.

**Layout:** back button (40px circle, `--card`, 1px `--color-neutral-300`, chevron flips under RTL) + "Step 2 of 5" 13px/700 `--color-neutral-600` + "Later" ghost skip, on one row padding 10px 0 16px. Then a 5-segment progress bar (each segment flex-1, height ~5px, radius 999px; filled `--color-accent`, empty `--color-neutral-300`). Then heading, sub, and field cards.

**Waist field (the one that matters most):** label + live value (heading 23px, tabular-nums), a range input 60–130, a cm/in segmented unit toggle, help text, and a **"Why do we ask?"** disclosure — 12.5px/700 `--color-accent-700` ghost button with a help-circle icon, expanding a `--color-accent-100` / `--color-accent-300` card at radius 16px, 12.5px/1.6 `--color-accent-900`.

> "Belly fat predicts diabetes better than overall weight, and it predicts it earlier in South Asian bodies. It is also the measurement that responds fastest when you act."

**Range slider spec:** track 8px radius 999px `--color-neutral-300`; thumb 24px `--color-accent` with a 3px `--card` ring and `0 1px 4px rgba(46,43,37,.3)`; `:focus-visible` thumb gets a 2px `--color-accent-700` outline at 2px offset.

**Every field needs its own "Why do we ask?"** — required by 1.4.1, not decoration. The eleven fields, their controls, and their rationale copy are tabulated in `ui_spec.md` §3. Ranges are enforced by the database, so the UI must **prevent** out-of-range input rather than reject it afterwards.

**Skip semantics:** skipping widens the returned range; it never blocks. Waist moves the band more than any other answer, so its skip copy says so.

## 05 · Population guidelines (optional)

**Purpose:** pick which population's clinical thresholds to apply. This screen has the most careful copy in the product.

**Layout:** back / "Optional step" / "Skip" row; heading 25px/1.22; sub 14px/1.55; then seven option rows; then a rationale card; then continue + note.

**Option row:** full-width button, 1.5px border, radius 20px, padding 14px 15px, 12px gap, 14.5px/600 label. Radio: 22px circle, 2px border, with an 11px inner dot. Selected: `--color-accent-100` bg, `--color-accent` border and dot. Unselected: `--card` bg, `--color-neutral-300` border, `--color-neutral-400` ring, transparent dot.

**Options:** South Asian · East or Southeast Asian · European · African or Caribbean · Middle Eastern or North African · Hispanic or Latino · Prefer not to say

**Rationale card:** `--color-accent-2-100` / `--color-accent-2-300`, radius 24px, padding 16px. Kicker "Why this matters" 11px uppercase .12em `--color-accent-2-800`; body 13px/1.6 `--color-accent-2-900`:

> "The same body scores 11–27% Moderate on European thresholds and 25–41% High on South Asian ones."

**Copy:** Head "Which population's health guidelines should we use?" — **never framed as a question about race or ethnicity.** Sub "Health thresholds differ between populations. Choosing yours helps us spot risk earlier." Note "Optional, and skipping changes nothing else. We never pre-select this from your language, name or location."

**Rules:** never pre-select. Genuinely skippable with **no nag**. Skipping leaves the app fully usable. The choice changes thresholds only — never the wording of the result.

**API:** `PATCH /profiles/:id`, `GET /regions/:code/cutoffs`.

## 06 · Calculating

**Purpose:** ~3 seconds of considered pause. The real assessment is faster; the pause stops a health estimate feeling flippant.

**Layout:** centered column, `min-height: 560px`, `text-align: center`.

**Components:**
- 132px ring: two concentric `<circle r="56" stroke-width="10">` — full track `--color-neutral-300`, arc `--color-accent` with `stroke-dasharray: 120 352`, `stroke-linecap: round`, whole SVG spinning `calcSpin 2.4s linear infinite`. Centered percentage, heading 24px, `--color-accent-700`, tabular-nums.
- Head heading 24px/1.25 margin-top 22px; sub 13.5px/1.6 `--color-neutral-700` max-width 280px.
- Three step rows: `--card`, 1px `--color-neutral-300`, radius 18px, padding 12px 14px, 11px gap. 22px circle badge, 2px border, filled `--color-accent` with an `--on-accent` check when complete. Pending rows sit at opacity .45.

**Step timing:** 0ms 18% → 900ms 46% (step 1 done) → 1850ms 78% (step 2 done) → 2900ms 100% and navigate to the result.

**Copy:** "Working out your estimate" / "Your answers are compared with published clinical scores. The model runs on this phone." Steps: "Reading your eleven answers", "Applying South Asian waist and BMI cutoffs", "Comparing with the IDRS clinical score".

**Rules:** never block on the network — the model is on-device. No progress claim the app can't keep. Failure routes to the error state, never an endless spinner. Nav pill hidden.

**API:** `POST /risk/assess`.

## 07 · Risk result + what-if simulator ⭐

The hero screen. Everything comes from the API response; nothing is computed client-side.

**Order of blocks, top to bottom:**

1. **Headline card** — `--card`, 1px `--color-neutral-300`, radius 30px, padding 20px 18px, `--shadow-sm`, centered. 12.5px/600 `--color-neutral-600` label "Estimated 10-year risk"; the **range** at heading 44px/1.1 (never a point value); a band chip (inline-flex, `--color-accent-100` bg, 1px `--color-accent-300`, `--color-accent-800`, radius 999px) — the band label reads bigger and firmer than the number; a four-segment band bar (height 11px, gap 3px) with a 12px `--pill` marker dot positioned at `bandLow × 2.4%` on a 14px rail.
2. **Tier 2 lab block** (only when a lab value exists) — sits **above** the factors and takes the headline, because a measurement outranks an estimate. `--color-accent-2-100` / `--color-accent-2-300`, radius 28px, padding 18px 17px. Kicker "Your lab result"; "HbA1c 6.1%" at heading 27px + "→ prediabetes range" at 13.5px/700; then the interpretation paragraph at 13px/1.6.
3. **"What you can change"** — heading 18.5px/1.25 + 12.5px `--color-neutral-600` sub, then factor rows. Points shown as `+30` in a pill: 13px/800 tabular-nums, `--color-accent-2-700` on `--color-accent-2-200`.
4. **"What you can't change — not your fault"** — same structure, `--color-neutral-700` on `--color-neutral-200` pills. The "not your fault" framing is deliberate and must survive translation.
5. **Factor row anatomy** — `--card`, 1px `--color-neutral-300`, radius 20px, padding 13px 15px. Name 14.5px/700 and the points pill on a baseline-aligned row; a plain-language reason at 12.5px/1.5 `--color-neutral-700`; a 7px `--color-neutral-200` track with a colored fill at the factor's weight.
6. **What-if simulator** — three sliders (weight, waist, activity) live-updating a simulated range. Same slider spec as the wizard.
7. **Primary CTA "Find a doctor"** — `--color-accent` pill, padding 16px, heading 15.5px. **Required on every risk result.**
8. Secondary outline pill "Get tested" (1.5px `--color-neutral-400`, transparent).
9. **"Add a blood test result"** dashed prompt (shown only when no lab exists) — 1.5px dashed `--color-accent-300`, `--color-accent-100`, radius 22px, `text-align: start`, 14.5px/700 title + 12.5px `--color-accent-700` sub.
10. **Basis + validation card** — `--card`, radius 22px. 12.5px/700 tabular-nums "Based on the IDRS score · 90 of 100 points", then an info-circle row with the validation line.
11. **Caveats disclosure** — a full-width row (1px `--color-neutral-300`, radius 20px, padding 13px 15px, 13.5px/700 label, chevron rotating 180° when open) expanding a `padding-inline-start: 20px` list at 12.5px/1.55.
12. **Persistent disclaimer footer** — `--color-neutral-200`, radius 18px, padding 13px 15px, 12px/1.55 `--color-neutral-800`. Never dismissible:

> This is a statistical estimate, not a diagnosis. Only a blood test ordered by a doctor can confirm diabetes.

**Validation status has three faces** (`validation_status`): `not_validated` → "Not yet validated for your region — this uses a published clinical score." (neutral, informational, **not** a warning — Bangladesh is here today); `provisional` → "Based on our model, still being validated locally." (small badge, slightly wider range); `validated` → nothing extra (no market has earned this).

**Caveats copy:** "Estimated from eleven self-reported answers. A blood test will always be more accurate." · "The published score was developed on Indian cohorts and is not yet validated on Bangladeshi data." · "Skipping a field widens the range. Waist moves your band more than any other answer."

**API fields consumed:** `band_label`, `range_low`, `range_high`, `modifiable_factors[]`, `fixed_factors[]`, `clinical_score`, `clinical_points`, `validation_status`, `caveats[]`, `disclaimer`.

## 08 · Lab values (Tier 2)

**Purpose:** offered **after** the first result, framed as an upgrade rather than a missing field.

**Layout:** back / title / spacer header row; heading 24px/1.25; sub 14px/1.55; two stepper cards; a preview card; save + skip; disclaimer footer.

**Stepper card:** `--card`, 1px `--color-neutral-300`, radius 26px, padding 17px 16px, `--shadow-sm`. Left: 14.5px/700 label + 12px/700 `--color-neutral-600` unit. Right: 36px circular −/+ buttons (1.5px `--color-neutral-300`, hover `--color-accent-100` + `--color-accent-300`) flanking a heading-23px tabular-nums value with `min-width: 64px`. Help text 12.5px/1.5 below.

- **HbA1c**, %, step 0.1, clamp 4.0–14.0. "Ask for this one first — a three-month average that needs no fasting."
- **Fasting glucose**, mmol/L or mg/dL per the unit setting, step 0.1, clamp 2.5–25.0. "Secondary. Add it only if your report carries it."

**Preview card:** `--color-accent-100` / `--color-accent-300`, radius 24px. Kicker "What this does to your estimate"; the old range struck through at 15px/700 `--color-neutral-600`; an arrow icon (flips under RTL); the narrowed range at heading 24px `--color-accent-900`. Note "A measurement outranks an estimate, so your result will lead with it."

**Interpretation bands:** `< 5.7` normal · `5.7–6.4` prediabetes · `≥ 6.5` above the diabetes threshold. Each has its own paragraph on the result screen; none uses the word diagnosis.

**API:** `POST /labs` then `POST /risk/assess`. Store canonical SI; units follow the region pack.

## 09 · Home / My plan

Day strip (7 pills, selected `--pill` / `--pill-fg` with `--shadow-md`), greeting, personal-plan card, trajectory card ("Your risk is trending down · 21% → 18% since June · waist −4 cm"), a risk-band chip that routes to the result, a daily check-in prompt, and today's meals list. Meal rows carry a tinted circular icon chip, name, and description + kcal in the user's numerals.

**Localized meal strings:** "2 roti, egg" · "Rice, fish curry" · "Tea without sugar, puffed rice" · "Not logged yet" (and their Bangla equivalents). Food names are content, not chrome — keep them in the string table.

## 10 · Calorie tracker

Dual concentric ring (calories + glycemic load) with a `--pill` circular badge at its center, remaining-kcal readout in tabular-nums, a target range line, macro chips (carbs / protein / GL), and a note explaining what drove the day's load. Never a bare "you failed" state; the copy names the next smaller portion instead.

## 11 · Camera meal review

A viewfinder block with a 2.5px dashed `--color-neutral-400` inset frame and a dark instruction strip (`rgba(46,43,37,.82)`, `--pill-fg`, radius 16px). Below it, editable portion rows in local units with per-item kcal, and the estimated total.

**Copy rule:** this screen scans **food**, never "your health" — see rule 3. Needs real food photography before build.

## 12 · Daily check-in

Energy and sleep inputs plus a three-symptom interceptor. If a reported symptom combination crosses the safety threshold, the check-in **routes to the urgent safety card** rather than returning to Home.

## 13 · Activity

Step goal ring with a `--pill` badge, current vs goal in local numerals, and a weekly bar row. Activity is one of only four inputs the clinical score reads, so its copy connects movement to the risk number explicitly.

## 14 · Glucose & vitals

Glucose readings paired to the meal that preceded them — the pairing is the point of the screen. Values in mmol/L or mg/dL per the unit setting; tabular-nums throughout.

## 15 · AI coach

Chat thread with a free-tier cap: "You've used today's 3 free coach questions. Premium makes them unlimited." Coaching content is **suppressed entirely** whenever a safety card is showing.

## 16 · Insights + doctor report

Two tabs: **Weekly** (patterns in plain language, e.g. "A steadier week than the last one") and **Doctor report** (a clinician-facing summary with a share action). The report is the artifact a patient hands to a doctor, so it carries the basis line and validation status too.

## 17 · Paywall

Monthly / annual plans priced in ৳ with bKash and Nagad as the payment rails, a 14-day trial badge, and an explicit free-forever list: **meal logging, risk assessment and safety alerts stay free forever.** A "Stay on the free plan for now" ghost exit is always present.

## 18 · Settings

Account, Appearance (Light / Dark / System), Language (15 languages + region pack), Units (mmol/L · kg or mg/dL · lb), Household profiles (invite-only, adults only), Subscription, Notifications (4 toggles), Data & privacy, sign out, delete account.

**Notification rule:** notifications never carry a health value — no glucose, weight, or risk figure on a lock screen.

## 19 · Safety & edge states

Five states, tab-switched in the prototype for review. In the app they are triggered, not browsable.

### Safety card — urgent
Muted red. `--safety-tint` bg, 1.5px `--safety-bd`, radius 30px, padding 20px 18px. 42px `--card` circle with a `--safety` triangle-alert icon; 11.5px/800 uppercase .1em kicker; heading 25px/1.22 in `--safety`; 14px/1.6 body. An emergency row: `--card`, 1px `--safety-bd`, radius 20px, with a phone icon and the local number from the region pack (**999** for Bangladesh) at 14.5px/800 plus a 12px "Emergency services · Bangladesh" sub. Primary CTA `--safety` fill with `#fffdf9` text; secondary ghost "I have already spoken to someone".

> "You logged a fasting reading of 15.2 mmol/L alongside blurred vision. That combination needs attention today, not next week."

**Replaces the screen entirely and suppresses coaching content.** This is the only place safety red is correct.

### Safety card — warning
Amber. `--caution-tint` / `--caution-bd` / `--caution`, info-circle icon, heading in `--color-text` (not amber). Non-blocking — coaching stays visible below the card.

> "Three morning readings this week sat above your usual range. Not urgent — write it down and take it with you."

CTA "Add to my visit notes", secondary "Dismiss".

### Under-18 block
`--color-accent-100` / `--color-accent-300`, person icon. Full-screen, kind, **no route past it**, and **no risk figure anywhere on it**. Offers a doctor route and nothing else. Enforced server-side as well as in the UI.

> "We cannot give a risk estimate for anyone under 18. A doctor or your family health worker can help you properly — please talk to them."

### Offline
`--color-neutral-200` / `--color-neutral-300`, wifi-off icon, `--pill` CTA. A quiet persistent banner at the top of the app, **never a blocking dialog** — the risk model runs on-device so assessment keeps working; check-ins and meals queue locally.

### Error
`--color-neutral-200`, retry icon, `--color-accent` CTA "Retry now", secondary "Leave it for now".

> "The server did not answer. The check-in is saved on this phone — tap retry, or leave it and it will send itself."

Every error says **what happened and what to do**. No apologies, no "something went wrong", and nothing the user typed is lost.

### Also specified in `ui_spec.md` §5, not yet designed
**Already diagnosed** — if a user reports existing T2D, the risk screen is the wrong screen. The backend returns a distinct response; handle it as a branch to a "your diabetes" view, not an error.

---

# Interactions & behavior

**Navigation graph:** Splash → Auth → (login) Home · (signup) Disclaimer → Wizard → Population → Calculating → Risk → Labs → Risk. Home is the hub for Tracker / Scan / Activity / Coach / Vitals / Insights / Settings via the floating nav pill and card taps. Check-in can divert to a safety card.

**Nav pill is hidden** on splash, auth, disclaimer, and calculating — no escape from a gate.

**Hover / press:** every interactive element gets a themed hover (usually `--color-accent-100` fill or `--color-accent-300` border) and a pressed state one ramp step past the base (`--color-accent-600` light, `--color-accent-400` dark). Focus is `2px solid var(--color-accent)` at `outline-offset: 2px` — never the browser default.

**Disabled / inert:** the disclaimer and signup submits render grey (`--color-neutral-300` on `--color-neutral-600`) and, when tapped, toast the reason rather than doing nothing.

**Toasts** confirm side effects in plain language and carry a privacy note where relevant: "Opening clinics near you · none of your data is shared", "Consent v1.0 recorded · 14 Aug 2026", "Lab value added · your estimate is now measurement-led", "Skipped · default thresholds from your region pack".

## State

| State | Type | Notes |
|---|---|---|
| `screen` | enum | 19 values, drives the whole view |
| `lang` | enum | 15 codes; drives strings, numerals, direction, font stack |
| `theme` | light / dark / system | remaps tokens on the app container |
| `unitIdx` | 0 / 1 | mmol/L · kg vs mg/dL · lb, app-wide |
| `profile` | id | 3 personas; switching swaps targets, risk band, glucose and step data |
| `consentTick`, `terms` | bool | gate their submits; never pre-set |
| `authTab` | login / signup | |
| `phone`, `fullName`, `pass` | string | auth fields |
| `obStep`, `obWaist`, `obUnit`, `obFam` | wizard | resumable per spec |
| `ancestry` | enum \| null | null means skipped, not unanswered |
| `calcStep` | 0–3 | drives the ring, percentage, and step ticks |
| `a1c`, `fast`, `hasLab` | lab | `hasLab` flips the result to measurement-led |
| `sim{w,waist,act}` | what-if sliders | live-recomputes the simulated range |
| `energy`, `sleep`, `symptoms` | check-in | symptom set can trigger safety routing |
| `edge` | enum | which edge state is showing |
| `offline` | bool | shows the app-wide banner |
| `caveatsOpen`, `why` | bool | disclosures |
| `toast` | string \| null | auto-clears after 2600ms |

**Data fetching:** the risk model runs **on-device**; assessment must not require a network round trip. Everything else (labs, check-ins, meals, consents) writes through a queue that drains on reconnect.

# Localization

15 languages scaffolded; **Bangla and English are first-class and must be designed at the same optical size.** Arabic and Urdu are RTL (Wave 3) and flip via `dir` plus `scaleX(-1)` on directional glyphs. Bangla, Hindi, Arabic and Urdu render **local numerals** (`০১২৩৪৫৬৭৮৯` etc.) through a single number formatter — every number in the UI goes through it.

Per-language font stacks: Bangla `Noto Sans Bengali`, Hindi `Noto Sans Devanagari`, Arabic/Urdu `Noto Naskh Arabic`, Latin `Figtree`. Test the Bangla and Latin faces in the same paragraph early.

**No fixed heights on anything containing text.** Test the longest realistic Bangla string in every button and label.

# Design tokens

Full machine-readable set in `design-tokens.json`. Headlines:

**Color** — ground `#f5ead8`, ink `#201e1d`, card `#fffdf9`, accent (terracotta) `#c67139`, second accent (sage) `#7a8a5e`, each with a 100–900 OKLCH ramp. Safety `#9f1239` (safety cards only), caution `#a2560b`. Dark theme remaps the same variable names on the app container, so all screens flip together.

Note the palette **diverges from `ui_spec.md` §6**, which proposed deep teal `#0F766E`. The prototype uses the bound Organic system's warm terracotta-and-sand instead; the safety and caution roles are carried over unchanged. Confirm which palette wins before building.

**Type** — Caprasimo (400 only) for headings, Figtree (400–800) for body. Tabular figures anywhere numbers stack.

**Radius** — 8 / 16 / 28 base; cards 20–30px; pills 999px; phone screen 44px.

**Space** — 4.4 / 8.8 / 13.2 / 17.6 / 26.4 / 35.2. In-app: 18px screen gutter, 13–20px card padding, 9–14px stack gap, 20px section gap.

**Shadow** — sm `0 1px 2px #2e2b25@14%`, md `0 3px 10px #2e2b25@16%`, lg `0 12px 32px #2e2b25@22%`.

**Icons** — Lucide at `stroke-width: 2.75`, round caps and joins.

**Motion** — see `design-tokens.json` `motion`; all durations 280ms–2.4s, no bounce, nothing celebratory.

# Layout mechanics to preserve

- **Flex/grid with `gap`** for every sibling group — never margin-per-child or whitespace spacing.
- **`inset-inline-start` / `-end`, `padding-inline`, `text-align: start`** everywhere. No `left`/`right`.
- **`text-wrap: pretty`** on every paragraph and heading.
- **`font-variant-numeric: tabular-nums`** on every number that can change or stack.
- **`min-width: 0`** on flex children holding text, so long Bangla strings ellipsize rather than blow out the row.

# Assets

- **Icons:** Lucide, inline SVG, stroke-width 2.75. No icon font.
- **Fonts:** Caprasimo, Figtree, Noto Sans Bengali, Noto Sans Devanagari, Noto Naskh Arabic — all Google Fonts. Bundle them; do not rely on a CDN at runtime on a low-connectivity market.
- **Meal photography: missing.** The camera-review screen has a placeholder. Real food images needed.
- **Waist-measurement diagram: missing.** Spec §2 asks for a wordless illustration; the prototype substitutes text.
- No text is baked into any image, and none may be.

# Files in this bundle

| File | What it is |
|---|---|
| `ByeByeDiabetes App.dc.html` | The design reference — all 19 screens, both themes, 15 languages, plus the in-page handoff panel with per-screen API/data/rule notes. Open in a browser; use the left index to move between screens, the language button to switch locales, and the Safety & edge states screen's tabs to see the five non-happy paths. |
| `ui_spec.md` | The original product spec: the eleven shipping rules, the twelve-screen target, the eleven questions with their "why we ask" copy, risk-result anatomy, the five edge states, palette/type constraints, and the two verbatim safety strings. **Where this and the prototype disagree on wording of a safety string, the spec wins.** |
| `design-tokens.json` | Machine-readable colors (light + dark), type, spacing, radii, shadows, motion, icon settings. |
| `README.md` | This document. |

# Pre-build checklist

- [ ] Every screen built in **both** Bangla and English at the same optical size
- [ ] Longest realistic Bangla string tested in every button and label
- [ ] No fixed heights on anything containing text
- [ ] Risk figures shown as **ranges** everywhere they appear
- [ ] Disclaimer visible on every screen showing a risk figure
- [ ] Doctor CTA present on every risk result
- [ ] Safety red used **only** on safety cards
- [ ] Body text 16sp minimum, AA contrast verified
- [ ] Dynamic type tested at the largest accessibility size
- [ ] Population-guidelines screen skippable with no nag, never pre-selected
- [ ] Under-18 path blocked in UI **and** server-side
- [ ] Empty, loading, offline, error and safety states all built
- [ ] Terms consent and medical disclaimer recorded as **two separate** consent rows
- [ ] Risk assessment verified working with the network disabled
- [ ] Screen-reader labels on every chart, factor row, and slider
- [ ] Bangla safety strings reviewed by a native-speaking clinician

Always read field definitions from `feature_spec.json` rather than either document — if the contract and a document disagree, the contract wins.
