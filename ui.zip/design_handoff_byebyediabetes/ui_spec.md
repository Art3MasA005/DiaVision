# Onboarding to Risk — Flutter Design Handoff

**Contract:** `feature_spec.json` v1.0.0 (frozen) · **Backend:** live, 220 tests · **Scope:** 12 screens + 5 states

> Also published as an artifact: <https://claude.ai/code/artifact/ad5b2ed4-ec1c-492d-9bdc-d1b5acfacad2>
> (private — sign in as the owning account to view)

---

## The whole job, in one sentence

A person answers eleven questions about themselves and gets back a calibrated estimate of whether they already have undetected high blood sugar — plus the two or three things they can actually change about it.

If a screen doesn't move someone toward answering those questions or understanding that answer, it isn't in this slice.

**The emotional brief:** this app handles a frightening topic for people who often can't afford the disease. Calm, clinical, warm. Not gamified, not cheerful, never scolding. A rising risk number must never be styled as an alarm — anxiety drives churn and, in a real patient, harm.

---

## 1. Eleven rules that decide whether this ships

From App Store guideline 1.4.1, Play's health policy, and the product's own safety rails. Breaking one gets the app rejected or hurts someone.

| # | Rule | Why |
|---|---|---|
| 1 | **Never a bare number.** Ranges only — `25–41%`, never `33%` | False precision on a health estimate is a lie the user can't detect |
| 2 | **Never the word "diagnosis"** | Banned everywhere: diagnose, cure, treat, reverse, clinically proven, medically accurate |
| 3 | **Never "scan your health"** | Apple auto-rejects apps implying vitals come from device sensors |
| 4 | **Never red for a bad number** | Red on "your risk went up" shames. Neutral, paired with one concrete action |
| 5 | **Never hide the disclaimer** | Persistent footer on every screen showing a risk figure — not a dismissible modal |
| 6 | **Never skip the doctor CTA** | Guideline 1.4.1 requires the reminder to consult a doctor |
| 7 | **Never fixed-height text containers** | Bangla runs taller than Latin; German ~35% longer |
| 8 | **Never `left`/`right`** — use `start`/`end` | Arabic and Urdu are Wave 3. Retrofitting RTL is brutal |
| 9 | **Never text baked into an image** | Untranslatable, invisible to screen readers |
| 10 | **Never below 16sp body text** | Older adults are a core demographic, not an edge case |
| 11 | **Never let an under-18 through** | Enforced server-side too, but the UI must not offer the path |

---

## 2. Twelve screens

Target: install to risk result in **under four minutes**.

| # | Screen | Notes |
|---|---|---|
| 01 | Splash | Under a second. No content. |
| 02 | Language | বাংলা / English. Bangla default when device locale is `bn`. Bangla numeral toggle (১২৩). |
| 03 | Value proposition | Three cards: what it does, what it can't do, why it's local. |
| 04 | **Disclaimer — BLOCKING** | Must tap to accept. No scroll-past, no pre-ticked box. Backend refuses signup without it. |
| 05 | Sign up / log in | Email + password. Errors say what went wrong *and* how to fix it. |
| 06 | Profile wizard — 6 steps | The eleven questions. Progress bar, back nav, resumable. |
| 07 | **Waist measurement guide** | Illustrated, wordless diagram + text. See below — earns its place. |
| 08 | Calculating | ~3s animated. Real work is faster; the pause makes it feel considered. |
| 09 | **Risk result** ⭐ | The hero. Full anatomy in §4. |
| 10 | Factor breakdown | Each factor with points and plain-language reason. |
| 11 | **What-if simulator** ⭐ | Sliders for weight, waist, activity. Live-updating risk. |
| 12 | Home | Minimal: risk band chip, re-take, settings. |

### Plus two optional screens

| Screen | When | Why |
|---|---|---|
| **Population guidelines** | After wizard, skippable | A Bangladeshi in London scores **11–27% Moderate** on European thresholds and **25–41% High** on South Asian ones. Same body. |
| **Lab values** | Offered after the result | "Have a recent blood test? Add it for a much more precise answer." Narrows 25–41% to 42–48%. |

---

## 3. The eleven questions

Every field carries a "Why do we ask?" affordance — required by 1.4.1, not decoration. Ranges are enforced by the database, so the UI should **prevent** rather than reject.

| Step | Field | Control | "Why do we ask?" |
|---|---|---|---|
| 1 | `age_years` | Number, 18–120 | Risk rises with age. Under 18 the app can't help — hard stop. |
| 1 | `sex_at_birth` | male / female | Waist thresholds differ by sex. Say "sex at birth" and explain why — not gender identity. |
| 2 | `height_cm` | Number, 100–250 · cm/ft | Used with weight to work out BMI. |
| 2 | `weight_kg` | Number, 25–300 · kg/lb | Used for BMI. Also the thing that changes when you act. |
| 3 | **`waist_cm`** ⭐ | Number, 40–200 + guide | The strongest single measurement for South Asians. Belly fat predicts diabetes better than overall weight. |
| 4 | `family_history` | none / second_degree / first_degree | The strongest factor you can't change. |
| 4 | `physical_activity` | 5-point, sedentary→very_active | Directly changeable, and one of only four things the clinical score looks at. |
| 4 | `smoker` | Yes / No | Raises insulin resistance. |
| 5 | `known_high_bp` | Yes / No | Often appears alongside blood sugar problems. |
| 5 | `on_bp_meds` | Yes / No | Part of the published risk score. |
| 5 | `history_high_glucose` | Yes / No | A previous high reading is the strongest single item in the score. |
| 5 | `gestational_diabetes_history` *(female only)* | Yes / No | Diabetes in pregnancy raises later risk. |
| 6 | `ancestry_cutoff_group` *(optional)* | 6 options + skip | See below. |

### Step 6 needs the most careful copy in the flow

Frame it as **"Which population's health guidelines should we use?"** — never as a question about race or ethnicity.

- Genuinely skippable, **no nag**. Skipping must leave the app fully usable.
- **Never pre-select** based on language, name, or location.
- Explain plainly: *"Health thresholds differ between populations. Choosing yours helps us spot risk earlier."*

Options: South Asian · East or Southeast Asian · European · African or Caribbean · Middle Eastern or North African · Hispanic or Latino · Prefer not to say

### Optional lab values

Offered **after** the first result, framed as an upgrade.

| Field | Unit | Note |
|---|---|---|
| **`hba1c_percent`** ⭐ | % | Ask for this first. Three-month average, no fasting, most people who've tested have it. |
| `fasting_glucose_mmol_l` | mmol/L · mg/dL | Secondary. Fewer people have it. |

---

## 4. Anatomy of the risk result

Everything comes straight from the API response. Nothing is computed client-side.

```
┌──────────────────────────────────────────────┐
│   HIGH                    ← band, the headline
│   Estimated risk 25–41%   ← range, never a point
├──────────────────────────────────────────────┤
│   WHAT YOU CAN CHANGE                        │
│     Sedentary                          +30   │
│     Waist 102 cm                       +20   │
│                                              │
│   WHAT YOU CAN'T CHANGE — not your fault     │
│     Age 35–49                          +20   │
│     Parent or sibling with diabetes    +20   │
├──────────────────────────────────────────────┤
│   [ See what would change this ]  ← simulator
│   [ Find a doctor ]               ← required
├──────────────────────────────────────────────┤
│   Based on the IDRS score (90/100)           │
│   Not yet validated for Bangladesh  ⓘ        │
├──────────────────────────────────────────────┤
│   This is a statistical estimate, not a      │
│   diagnosis. Only a blood test ordered by    │
│   a doctor can confirm diabetes.             │
└──────────────────────────────────────────────┘
```

| Element | From | Design note |
|---|---|---|
| Band | `band_label` | Low · Moderate · High · Very High. Bigger than the number. |
| Range | `range_low` / `range_high` | Render as a band, not a line. Never show `probability` alone. |
| Changeable factors | `modifiable_factors[]` | Always first. The actionable half. |
| Fixed factors | `fixed_factors[]` | Separate section, softer weight. "Not your fault" framing is deliberate. |
| Basis line | `clinical_score`, `clinical_points` | Quiet but present. It's what makes the number defensible. |
| Validation status | `validation_status` | Three states below. Never hide. |
| Caveats | `caveats[]` | Collapsible is fine. One tap away is not optional. |
| Disclaimer | `disclaimer` | Persistent footer. Never dismissible. |

### Validation status has three faces

| State | User sees | Treatment |
|---|---|---|
| `not_validated` | "Not yet validated for your region — this uses a published clinical score." | Neutral, informational. **Not** a warning. Bangladesh is here today. |
| `provisional` | "Based on our model, still being validated locally." | Small badge. Slightly wider range. |
| `validated` | Nothing extra | No market has earned this yet. |

### Tier 2 variant

When a lab value is entered, a results block appears **above** the factors and takes the headline. A measurement outranks an estimate; the layout should say so.

```
   YOUR LAB RESULT
     HbA1c 6.1%  →  prediabetes

   Your HbA1c is in the prediabetes range. This is a
   warning sign, not a diagnosis, and it is often
   reversible with diet and activity changes.
```

---

## 5. Five states that aren't the happy path

**Safety card** — *replaces* the screen entirely, suppresses coaching content. Two severities: **urgent** (muted red, "contact a doctor today") and **warning** (amber, "worth mentioning to your doctor"). Both carry the local emergency number (`999` for Bangladesh, from the region pack). This is the one place muted red is correct — firm, not frightening.

**Under-18 block** — full-screen, kind, no way around it. Offers a doctor route and nothing else.

**Already diagnosed** — if someone reports existing T2D, the risk screen is the wrong screen. Route to a "your diabetes" view. The backend returns a distinct response, so handle it as a branch, not an error.

**Offline** — the risk model will run on-device, so assessment must work with no connection. Quiet persistent banner, not a blocking dialog.

**Errors and empties** — every error says what went wrong *and* what to do. No apologies, no "something went wrong."

---

## 6. Palette and type

Starting direction, not a finished system. Deep teal reads as health and is culturally positive in Bangladesh; warm off-white keeps it from feeling like a hospital.

| Role | Hex |
|---|---|
| Primary | `#0F766E` |
| Primary deep | `#134E4A` |
| Surface | `#FBF9F4` |
| Caution | `#A2560B` |
| **Safety only** | `#9F1239` |
| Ink | `#12211F` |

> **The safety red has exactly one job.** Genuine safety events and nowhere else. Not on a high risk band, not on a missed goal, not on a rising trend. The moment it appears somewhere ordinary, it stops meaning anything.

| Role | Face | Constraint |
|---|---|---|
| Bangla | Hind Siliguri / Noto Sans Bengali | Must sit comfortably beside Latin at the same optical size. Never an afterthought. |
| Latin | A humanist sans | Pair deliberately with the Bangla face — test them in the same paragraph early. |
| Numerals | Tabular figures | Anywhere numbers stack: factor points, ranges, trends. |

16sp minimum body, full dynamic type, AA contrast, screen-reader labels on every chart and factor row.

---

## 7. Two strings that must not be paraphrased

**First launch — blocking:**

> Bye Bye Diabetes gives lifestyle and risk information. It is **not a medical device** and does **not diagnose or treat** any condition. Its estimates can be wrong. Always talk to a registered doctor before changing your diet, exercise, or any medication. If you take insulin or diabetes medication, do not change your dose based on this app.

**Risk screen footer — persistent:**

> This is a statistical estimate, not a diagnosis. Only a blood test ordered by a doctor can confirm diabetes.

Both need a Bangla translation reviewed by a **native-speaking clinician** — not machine translation, not a developer's best guess. Applies to every safety string in the app.

---

## 8. Checklist before handoff back

- [ ] Every screen designed in **both** Bangla and English, same optical size
- [ ] Longest realistic Bangla string tested in every button and label
- [ ] No fixed heights on anything containing text
- [ ] Risk figures shown as ranges everywhere they appear
- [ ] Disclaimer visible on every screen showing a risk figure
- [ ] Doctor CTA present on every risk result
- [ ] Safety red used **only** on safety cards
- [ ] Body text 16sp minimum, AA contrast verified
- [ ] Dynamic type tested at largest accessibility size
- [ ] Population-guidelines screen skippable with no nag
- [ ] Empty, loading, offline, error and safety states all designed

---

## Generating the field list yourself

```powershell
python ml/scripts/show_questions.py            # required questions + why we ask
python ml/scripts/show_questions.py --tier 2   # adds the labs
python ml/scripts/show_questions.py --json     # machine-readable, for the wizard
```

Always read from the contract rather than this document — if the two ever disagree, `feature_spec.json` wins.
